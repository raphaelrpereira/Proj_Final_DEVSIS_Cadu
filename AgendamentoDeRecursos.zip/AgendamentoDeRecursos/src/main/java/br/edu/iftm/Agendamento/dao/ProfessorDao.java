package br.edu.iftm.Agendamento.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import br.edu.iftm.Agendamento.domain.Professor;

public class ProfessorDao {
	
	@PersistenceContext(name="AgendamentoPU")
	private EntityManager entityManager;
	
	@SuppressWarnings("unchecked")
	public List<Professor> getProfessor() {
		Query query = entityManager.createQuery("from Professor p");
		return query.getResultList();
	}
	
	public Professor getProfessorId(Integer id) {
		return entityManager.find(Professor.class,id);
	}
	
	@Transactional
	public void excluirProfessor(Integer id) {
		Professor p = getProfessorId(id);
		entityManager.remove(p);
	}
	
	@Transactional
	public void inserirProfessor(Professor professor) {
		//entityManager.getTransaction().begin();
		entityManager.persist(professor);
		//entityManager.getTransaction().commit();
		//entityManager.persist(new Projeto());
	}
	
	@Transactional
	public void atualizarProfessor(Professor professor) {
		professor = entityManager.merge(professor);
		entityManager.persist(professor);
	}
	
}
