package br.edu.iftm.Agendamento.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="TB_AGENDAMENTOS")
public class Agendamentos implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	
	@Column(name="COD_AGENDAMENTO")
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name="COD_PROFESSOR",referencedColumnName="COD_PROFESSOR")
	private Professor COD_PROFESSOR;
	
	@ManyToOne
	@JoinColumn(name="COD_RECURSO",referencedColumnName="COD_RECURSO")
	private Recurso COD_RECURSO;
	
	@Temporal(TemporalType.DATE)
	@Column(name="DATA")
	private Date dataAgenda;
	
	@Column(name="HORA_INICIO")
	private String horaInicio;
	
	@Column(name="HORA_FIM")
	private String horaFim;

	public Agendamentos() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Professor getCOD_PROFESSOR() {
		return COD_PROFESSOR;
	}

	public void setCOD_PROFESSOR(Professor cOD_PROFESSOR) {
		COD_PROFESSOR = cOD_PROFESSOR;
	}

	public Recurso getCOD_RECURSO() {
		return COD_RECURSO;
	}

	public void setCOD_RECURSO(Recurso cOD_RECURSO) {
		COD_RECURSO = cOD_RECURSO;
	}

	public Date getDataAgenda() {
		return dataAgenda;
	}

	public void setDataAgenda(Date dataAgenda) {
		this.dataAgenda = dataAgenda;
	}

	public String getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(String horaInicio) {
		this.horaInicio = horaInicio;
	}

	public String getHoraFim() {
		return horaFim;
	}

	public void setHoraFim(String horaFim) {
		this.horaFim = horaFim;
	}

}
