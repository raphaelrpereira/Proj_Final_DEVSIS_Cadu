package br.edu.iftm.Agendamento.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="TB_PROFESSOR")
@XmlRootElement
public class Professor implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="COD_PROFESSOR")
	private Integer id;
	
	@Column(name="NM_PROFESSOR",nullable=false,length=200)
	private String nome;
	
	@OneToMany(mappedBy="COD_PROFESSOR")
	private List<Agendamentos> profAgendamentos;
	
	
	public Professor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public List<Agendamentos> getProfAgendamentos() {
		return profAgendamentos;
	}

	public void setProfAgendamentos(List<Agendamentos> profAgendamentos) {
		this.profAgendamentos = profAgendamentos;
	}

	
}
