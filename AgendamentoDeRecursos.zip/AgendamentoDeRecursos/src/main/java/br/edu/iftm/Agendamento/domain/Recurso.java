package br.edu.iftm.Agendamento.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TB_RECURSOS")
public class Recurso implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="COD_RECURSO")
	private Integer id;
	
	@Column(name="NOME_RECURSO",nullable=false,length=200)
	private String nome;
	
	@Column(name="CAPACIDADE")
	private Integer capacidade;

	@OneToMany(mappedBy="COD_RECURSO")
	private List<Agendamentos> recusoAgendamentos;

	public Recurso() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void getCapacidade(Integer capacidade) {
		this.capacidade = capacidade;
	}
	
	public void setCapacidade(Integer capacidade) {
		this.capacidade = capacidade;
	}

	public List<Agendamentos> getRecusoAgendamentos() {
		return recusoAgendamentos;
	}

	public void setRecusoAgendamentos(List<Agendamentos> recusoAgendamentos) {
		this.recusoAgendamentos = recusoAgendamentos;
	}


}
