package br.edu.iftm.Agendamento.facade.rs;

import javax.ws.rs.core.Application;
import javax.ws.rs.ApplicationPath;

@ApplicationPath("rs")
public class RestApplication extends Application {
}