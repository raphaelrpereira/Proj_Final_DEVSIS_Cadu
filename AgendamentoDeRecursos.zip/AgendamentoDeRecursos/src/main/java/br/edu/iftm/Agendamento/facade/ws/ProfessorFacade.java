package br.edu.iftm.Agendamento.facade.ws;

import java.util.List;

import javax.inject.Inject;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import br.edu.iftm.Agendamento.dao.ProfessorDao;
import br.edu.iftm.Agendamento.domain.Professor;

@WebService(serviceName="ws/professor")
public class ProfessorFacade {
	
	@Inject
	private ProfessorDao professorDao;
	
	@WebMethod
	public List<Professor> getProfessor() {
		List<Professor> professores = professorDao.getProfessor();
//		for (Pessoa p: pessoas) {
//			p.setParticipacoes(null);
//			p.setProjetosAutor(null);
//		}
		return professores;
	}
	
	@WebMethod
	public Professor getProfessorId(@WebParam(name="codigoProfessor") Integer id) {
		Professor p = professorDao.getProfessorId(id);
		if (p != null) {
			p.setProfAgendamentos(null);
			//p.setProjetosAutor(null);	
		}
		return p;
	}
	
	@WebMethod
	public void excluirProfessor(@WebParam(name="codigoProfessor") Integer id) {
		professorDao.excluirProfessor(id);
	}
	
	@WebMethod
	public void atualizarProfessor(@WebParam(name="professor") Professor professor) {
		professorDao.atualizarProfessor(professor);
	}
	
	@WebMethod
	public void salvarProfessor(@WebParam(name="professor") Professor professor) {
		professorDao.inserirProfessor(professor);
	}
	
	

}
